
This directory contains libraries for use with qtpy_synth.
For actual applications, see the other directories
