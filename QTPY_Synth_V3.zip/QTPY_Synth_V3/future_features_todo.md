# Future features TODO

## 1) Persist pad tuning inside patches
- Save/restore per-pad tuning (coarse MIDI note + fine cents) as part of a patch.
- When loading a patch, update the tuned pad note values and refresh Screen2 TUNE UI.
- Consider backward compatibility for older patch JSON files (missing tune fields).

## 2) Optional arpeggiator in Setup screen
- Add Arp On/Off and Arp Shape (Up, Down, Up+Down, Down+Up).
- Root note = last pressed pad.
- Arp should play only the 4 pad-assigned notes.
- Interaction with Latch:
  - If Latch is OFF, Arp can be enabled normally.
  - If Latch is ON, either disable Arp or force Latch OFF when enabling Arp (choose behavior).
- Use the empty space at the bottom of Screen2 for controls/status.
