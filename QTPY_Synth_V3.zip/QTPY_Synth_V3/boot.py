# boot.py - make CIRCUITPY writable while connected over USB (keep serial for Thonny)
import storage
import usb_cdc

# Disable USB mass storage so the host OS won't mount CIRCUITPY read-only.
storage.disable_usb_drive()

# Ensure filesystem is writable
storage.remount("/", readonly=False)

# Keep the USB serial console enabled (Thonny uses it)
usb_cdc.enable(console=True, data=True)
