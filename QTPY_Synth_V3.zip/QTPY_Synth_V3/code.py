# wavesynth_code.py -- wavesynth for qtpy_synth
# 28 Jul 2023 - @todbot / Tod Kurt
# part of https://github.com/todbot/qtpy_synth
#
#  UI:
#  - Display shows four lines of two parameters each
#  - The current editable parameter pair is underlined, adjustable by the knobs
#  - The knobs have "catchup" logic  (
#       (knob must pass through the displayed value before value can be changed)
#
#  - Key tap (press & release) == change what editable line (what knobs are editing)
#  - Key hold + touch press = load patch 1,2,3,4  (turned off currently)
#  - Touch press/release == play note / release note
#

import asyncio
import time
import usb_midi

from qtpy_synth.hardware import Hardware
from qtpy_synth.synthio_instrument import WavePolyTwoOsc, Patch, FiltType, WaveType
import qtpy_synth.winterbloom_smolmidi as smolmidi

from wavesynth_display import WavesynthDisplay

import microcontroller
import os
import json
import supervisor
microcontroller.cpu.frequency = 250_000_000

time.sleep(2)  # let USB settle down

touch_midi_notes = [40, 48, 52, 55] # can be float

patch1 = Patch('oneuno')
patch2 = Patch('twotoo')
patch3 = Patch('three')
patch4 = Patch('fourfor')
patches = (patch1, patch2, patch3, patch4)

patch1.filt_env_params.attack_time = 0.1
patch1.amp_env_params.attack_time = 0.01

patch2.filt_type = FiltType.HP
patch2.wave = 'square'
patch2.detune=1.01
patch2.filt_env_params.attack_time = 0.0 # turn off filter  FIXME
patch2.amp_env_params.release_time = 1.0

patch3.waveformB = 'square'  # show off wavemixing
patch3.filt_type = FiltType.BP

patch4.wave_type = WaveType.WTB
patch4.wave = 'PLAITS02'  # 'MICROW02' 'BRAIDS04'
patch4.wave_mix_lfo_amount = 0.23
#patch4.detune = 0  # disable 2nd oscillator
patch4.amp_env_params.release_time = 0.5

print("--- qtpy_synth wavesynth starting up ---")

qts = Hardware()
inst = WavePolyTwoOsc(qts.synth, patch4)
wavedisp = WavesynthDisplay(qts.display, inst.patch)

# let's get the midi going
midi_usb_in = smolmidi.MidiIn(usb_midi.ports[0])
midi_uart_in = smolmidi.MidiIn(qts.midi_uart)

def map_range(s, a1, a2, b1, b2):  return  b1 + ((s - a1) * (b2 - b1) / (a2 - a1))
def inv_map_range(v, b1, b2, a1, a2):
    # inverse of map_range: value v in [b1..b2] -> pot s in [a1..a2]
    return a1 + ((v - b1) * (a2 - a1) / (b2 - b1))

async def instrument_updater():
    while True:
        inst.update()
        await asyncio.sleep(0.01)  # as fast as possible

async def display_updater():
    while True:
        wavedisp.display_update()
        await asyncio.sleep(0.1)


async def midi_handler():
    while True:
        while msg := midi_usb_in.receive() or midi_uart_in.receive():
            if msg.type == smolmidi.NOTE_ON:
                inst.note_on(msg.data[0])
                qts.led.fill(0xff00ff)
            elif msg.type == smolmidi.NOTE_OFF:
                inst.note_off(msg.data[0])
                qts.led.fill(0x000000)
            elif msg.type == smolmidi.CC:
                ccnum = msg.data[0]
                ccval = msg.data[1]
                qts.led.fill(ccval)
                if ccnum == 71:  # "sound controller 1"
                    new_wave_mix = ccval/127
                    print("wave_mix:", new_wave_mix)
                    inst.patch.wave_mix = new_wave_mix
                elif ccnum == 1: # mod wheel
                    inst.patch.wave_mix_lfo_amount = ccval/127 * 50
                    #inst.patch.wave_mix_lfo_rate = msg.value/127 * 5
                elif ccnum == 74: # filter cutoff
                    inst.patch.filt_f = ccval/127 * 8000

        await asyncio.sleep(0.001)


async def input_handler():

    # fixme: put these in qtpy_synth.py? no I think they are part of this "app"
    knob_mode = 0  # 0=frequency, 1=wavemix, 2=, 3=
    key_held = False
    key_with_touch = False
    knob_saves = [ (0,0) for _ in range(4) ]  # list of knob state pairs
    param_saves = [ (0,0) for _ in range(4) ]  # list of param state pairs for knobs
    knobA_pickup, knobB_pickup = False, False
    knobA, knobB = 0,0

    # Quick Save/Load state
    key_action = "NONE"  # NONE|TAP|LOAD_ARMED|SAVE_ARMED|DONE|CANCEL|ENTER_SETUP
    key_down_time = None
    arm_mode = None      # None|'load'|'save'
    arm_feedback_sent = False
    slot_selected = False
    # Screen #2 (Setup) placeholder state
    in_screen2 = False
    screen2_mode = 0  # 0=Latch, 1=Tune  # TODO(future): вернуть 2=Load,3=Save
    screen2_key_down_time = None
    screen2_ignore_release = False
    latch_states = [False, False, False, False]  # latched on/off per pad
    latch_play_note = [0.0, 0.0, 0.0, 0.0]  # exact note used for note_off when latched
    # Screen2: TUNE state (per pad)
    tune_pad_idx = None  # 0..3, last selected pad in TUNE
    pad_note_int = [int(n) for n in touch_midi_notes]
    pad_fine_cents = [0, 0, 0, 0]  # -100..+100
    tune_pad_pressed = [False, False, False, False]
    tune_play_note = [0.0, 0.0, 0.0, 0.0]
    tuneA_pickup = False
    tuneB_pickup = False
    tuneA = 0
    tuneB = 0

    def _screen2_label():
        # TODO(future): вернуть LOAD/SAVE
        return ("LATCH", "TUNE")[screen2_mode]
        # return ("LATCH", "TUNE", "LOAD", "SAVE")[screen2_mode]

    def _screen2_show(persist=True):
        # Use bottom status line as a placeholder "screen"
        try:
            wavedisp.display_status("SETUP: " + _screen2_label(), timeout_ms=(999999 if persist else 1500))
        except Exception:
            pass

    def _note_name(midi_note_int: int) -> str:
        names = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        n = int(midi_note_int)
        name = names[n % 12]
        octave = (n // 12) - 1
        return f"{name}{octave}"

    def _clamp(v, lo, hi):
        if v < lo:
            return lo
        if v > hi:
            return hi
        return v

    def _note_val_for_pad(k: int) -> float:
        # tuned note value for pads (applies in Screen1 and Screen2)
        try:
            return float(pad_note_int[k]) + (float(pad_fine_cents[k]) / 100.0)
        except Exception:
            return float(touch_midi_notes[k])


    def _ensure_patches_dir():
        try:
            os.stat("/patches")
        except OSError:
            try:
                os.mkdir("/patches")
            except OSError:
                pass

    def _env_to_dict(env):
        return {
            "attack_time": float(env.attack_time),
            "decay_time": float(env.decay_time),
            "release_time": float(env.release_time),
            "attack_level": float(env.attack_level),
            "sustain_level": float(env.sustain_level),
        }

    def _env_from_dict(env, d):
        if not d:
            return
        for k in ("attack_time","decay_time","release_time","attack_level","sustain_level"):
            if k in d:
                setattr(env, k, float(d[k]))

    def patch_to_dict(p):
        return {
            "wave_select": p.wave_select(),
            "wave_mix": float(p.wave_mix),
            "detune": float(p.detune),
            "wave_mix_lfo_amount": float(p.wave_mix_lfo_amount),
            "wave_mix_lfo_rate": float(p.wave_mix_lfo_rate),
            "filt_type": int(p.filt_type),
            "filt_f": float(p.filt_f),
            "filt_q": float(p.filt_q),
            "filt_env_params": _env_to_dict(p.filt_env_params),
            "amp_env_params": _env_to_dict(p.amp_env_params),
        }

    def patch_apply_dict(p, d):
        # wave_select changes require reload_patch()
        if "wave_mix" in d: p.wave_mix = float(d["wave_mix"])
        if "detune" in d: p.detune = float(d["detune"])
        if "wave_mix_lfo_amount" in d: p.wave_mix_lfo_amount = float(d["wave_mix_lfo_amount"])
        if "wave_mix_lfo_rate" in d: p.wave_mix_lfo_rate = float(d["wave_mix_lfo_rate"])
        if "filt_type" in d: p.filt_type = int(d["filt_type"])
        if "filt_f" in d: p.filt_f = float(d["filt_f"])
        if "filt_q" in d: p.filt_q = float(d["filt_q"])
        if "filt_env_params" in d:
            _env_from_dict(p.filt_env_params, d["filt_env_params"])
        if "amp_env_params" in d:
            _env_from_dict(p.amp_env_params, d["amp_env_params"])

    def slot_path(slot):
        return "/patches/slot_%03d.json" % slot

    def save_slot(slot):
        _ensure_patches_dir()
        path = slot_path(slot)
        data = patch_to_dict(inst.patch)
        try:
            with open(path, "w") as f:
                json.dump(data, f)
            print("Saved slot", slot, "->", path)
            try: wavedisp.display_status("Saved %d" % slot, timeout_ms=1500)
            except Exception: pass
        except OSError as e:
            print("SAVE ERR", e)
            try: wavedisp.display_status("SAVE ERR", timeout_ms=1500)
            except Exception: pass

    def load_slot(slot):
        path = slot_path(slot)
        try:
            with open(path, "r") as f:
                data = json.load(f)
            # wave_select first
            if "wave_select" in data:
                reload_patch(data["wave_select"])
            patch_apply_dict(inst.patch, data)
            inst.reload_patch()
            # IMPORTANT: param_saves must reflect the loaded patch (not the pre-load values)
            param_saves[0] = wavedisp.wave_select_pos(), inst.patch.wave_mix
            param_saves[1] = inst.patch.detune, inst.patch.wave_mix_lfo_amount
            param_saves[2] = inst.patch.filt_type, inst.patch.filt_f
            param_saves[3] = inst.patch.filt_q, inst.patch.filt_env_params.attack_time
            wavedisp.display_update()
            resync_knobs_to_params()
            print("Loaded slot", slot, "<-", path)
            try: wavedisp.display_status("Loaded %d" % slot, timeout_ms=1500)
            except Exception: pass
        except Exception as e:
            print("LOAD ERR", e)
            try: wavedisp.display_status("LOAD ERR", timeout_ms=1500)
            except Exception: pass


    def reload_patch(wave_select):
        print("reload patch!", wave_select)

        # 1) запомнить все звучащие ноты (held pads / tune preview / latch)
        try:
            active_notes = list(inst.voices.keys())
        except Exception:
            active_notes = []

        inst.patch.set_by_wave_select(wave_select)
        inst.reload_patch()

        # 2) сначала восстановить latch (он "главный", и нота должна быть текущая tuned)
        restored = set()
        for k in range(4):
            if latch_states[k]:
                note_val = _note_val_for_pad(k)
                latch_play_note[k] = note_val
                inst.note_on(note_val)
                restored.add(note_val)

        # 3) восстановить остальные ноты, которые звучали до reload (например удерживаемый pad)
        for n in active_notes:
            if n not in restored:
                inst.note_on(n)

        # дальше всё как было
        param_saves[0] = wavedisp.wave_select_pos(), inst.patch.wave_mix
        param_saves[1] = inst.patch.detune, inst.patch.wave_mix_lfo_amount
        param_saves[2] = inst.patch.filt_type, inst.patch.filt_f
        param_saves[3] = inst.patch.filt_q, inst.patch.filt_env_params.attack_time
        
    def resync_knobs_to_params():
        nonlocal knob_saves, knobA, knobB, knobA_pickup, knobB_pickup

        # mode 0: wave_select_pos (0..len-1), wave_mix (0..1)
        wave_select_pos, wave_mix = param_saves[0]
        kA0 = int(inv_map_range(wave_select_pos, 0, len(wavedisp.wave_selects)-1, 0, 65535))
        kB0 = int(inv_map_range(wave_mix, 0, 1, 0, 65535))
        knob_saves[0] = (kA0, kB0)

        # mode 1: detune (1..1.1), wave_lfo (0..1)
        detune, wave_lfo = param_saves[1]
        kA1 = int(inv_map_range(detune, 1, 1.1, 300, 65300))
        kB1 = int(inv_map_range(wave_lfo, 0, 1, 0, 65535))
        knob_saves[1] = (kA1, kB1)

        # mode 2: filt_type (0..3), filt_f (100..8000)
        filt_type, filt_f = param_saves[2]
        kA2 = int(inv_map_range(filt_type, 0, 3, 0, 65535))
        kB2 = int(inv_map_range(filt_f, 100, 8000, 300, 65300))
        knob_saves[2] = (kA2, kB2)

        # mode 3: filt_q (0.5..2.5), filt_env (1..0.01)
        filt_q, filt_env = param_saves[3]
        kA3 = int(inv_map_range(filt_q, 0.5, 2.5, 0, 65535))
        kB3 = int(inv_map_range(filt_env, 1, 0.01, 300, 65300))
        knob_saves[3] = (kA3, kB3)

        # set current virtual knob position to current mode's saved position
        knobA, knobB = knob_saves[knob_mode]
        knobA_pickup = False
        knobB_pickup = False
        
    # --- INIT param_saves from current patch (fix wave_mix saving) ---
    try:
        wave_select_pos = wavedisp.wave_select_pos()
    except Exception:
        wave_select_pos = 0  # если текущий wave_select не в списке wavedisp.wave_selects

    param_saves[0] = (wave_select_pos, inst.patch.wave_mix)
    param_saves[1] = (inst.patch.detune, inst.patch.wave_mix_lfo_amount)
    param_saves[2] = (inst.patch.filt_type, inst.patch.filt_f)
    param_saves[3] = (inst.patch.filt_q, inst.patch.filt_env_params.attack_time)
    resync_knobs_to_params()
    # --- END INIT ---
    
    while True:
        # KNOB input
        (knobA_new, knobB_new) = qts.read_pots()
        
        if not in_screen2:
            # simple knob pickup logic: if the real knob is close enough to
            if abs(knobA - knobA_new) <= 1000:  # knobs range 0-65535
                knobA_pickup = True
            if abs(knobB - knobB_new) <= 1000:
                knobB_pickup = True

            if knobA_pickup:
                knobA = knobA_new
            if knobB_pickup:
                knobB = knobB_new
        else:
            # while in Screen2, do NOT let Screen1 pickup "catch" the knobs
            knobA_pickup = False
            knobB_pickup = False

        # TOUCH input
        if touches := qts.check_touch():
            for touch in touches:

                # --- FIXED touch handling block (pressed + released) ---

                if touch.pressed:
                    
                    # Screen2: LATCH mode (screen2_mode==0)
                    if in_screen2 and screen2_mode == 0:
                        k = touch.key_number
                        if 0 <= k <= 3:
                            latch_states[k] = not latch_states[k]
                            wavedisp.set_latch_states(latch_states)

                            if latch_states[k]:
                                note_val = _note_val_for_pad(k)   # tuned note (int + cents)
                                latch_play_note[k] = note_val     # remember exact note for note_off
                                inst.note_on(note_val)
                                qts.led.fill(0xff00ff)
                            else:
                                inst.note_off(latch_play_note[k]) # turn off exact note we turned on
                                qts.led.fill(0)
                                

                        key_with_touch = True
                        continue



                    # Screen2: TUNE mode (screen2_mode==1)
                    if in_screen2 and screen2_mode == 1:
                        k = touch.key_number
                        if 0 <= k <= 3:
                            tune_pad_idx = k
                            tune_pad_pressed[k] = True

                            base = int(touch_midi_notes[k])
                            coarse_offset = _clamp(pad_note_int[k] - base, -12, 12)
                            fine = _clamp(pad_fine_cents[k], -100, 100)

                            tuneA = int(inv_map_range(coarse_offset, -12, 12, 0, 65535))
                            tuneB = int(inv_map_range(fine, -100, 100, 0, 65535))
                            tuneA_pickup = False
                            tuneB_pickup = False

                            note_val = _note_val_for_pad(k)
                            tune_play_note[k] = note_val

                            try:
                                wavedisp.set_tune(_note_name(pad_note_int[k]), pad_fine_cents[k])
                            except Exception:
                                pass

                            qts.led.fill(0xff00ff)

                            # Если этот pad уже залочен — используем latch-голос (без второго голоса)
                            if latch_states[k]:
                                # выключаем старую залоченную ноту и включаем новую tuned
                                inst.note_off(latch_play_note[k])
                                latch_play_note[k] = note_val
                                inst.note_on(note_val)
                            else:
                                # обычный превью-голос в Tune
                                inst.note_on(note_val)

                            key_with_touch = True
                            continue

                    # If we're armed for quick load/save, pads select slot 1-4
                    if arm_mode in ("load", "save"):
                        slot = touch.key_number + 1
                        print("ARM PAD pressed:", touch.key_number, "slot=", slot, "mode=", arm_mode)
                        if 1 <= slot <= 4:
                            if arm_mode == "load":
                                load_slot(slot)
                            else:
                                save_slot(slot)
                            print("ARM action done:", arm_mode, slot)
                            slot_selected = True
                            key_action = "DONE"
                            arm_mode = None
                        key_with_touch = True
                        continue

                    elif key_held:
                        key_with_touch = True
                        continue

                    else:
                        qts.led.fill(0xff00ff)
                        k = touch.key_number
                        inst.note_on(_note_val_for_pad(k))
                        continue

                if touch.released:

                    # Screen2: LATCH release (ignore)
                    if in_screen2 and screen2_mode == 0:
                        key_with_touch = False
                        continue

                    # Screen2: TUNE release
                    if in_screen2 and screen2_mode == 1:
                        k = touch.key_number
                        if 0 <= k <= 3:
                            tune_pad_pressed[k] = False
                            qts.led.fill(0)

                            # Если latch ON — не выключаем ноту (она должна продолжать звучать)
                            if not latch_states[k]:
                                inst.note_off(tune_play_note[k])

                        key_with_touch = False
                        continue

                    if key_with_touch:
                        key_with_touch = False
                        continue

                    qts.led.fill(0)
                    k = touch.key_number
                    inst.note_off(_note_val_for_pad(k))
                    continue

                # --- END FIXED touch handling block ---

        # Screen #2 (Setup) placeholder key handling (MUST be outside TOUCH block)
        if in_screen2:
            key = qts.check_key()
            if key:
                if key.pressed:
                    screen2_key_down_time = time.monotonic()

                if key.released:
                    if screen2_ignore_release:
                        screen2_ignore_release = False
                        continue
                    held = 0.0
                    if screen2_key_down_time is not None:
                        held = time.monotonic() - screen2_key_down_time
                    screen2_key_down_time = None

                    # Hold >=2s in Screen2 => exit back to Screen1
                    if held >= 2.0:
                        in_screen2 = False
                        wavedisp.set_screen(1)
                        wavedisp.selected_info = knob_mode
                        wavedisp.display_status("", timeout_ms=1)  # optional: clear bottom line
                        key_action = "NONE"
                        knobA_pickup = False
                        knobB_pickup = False
                        (knobA, knobB) = knob_saves[knob_mode]
                        continue


                    # Short tap => cycle Screen2 mode placeholders
                    # TODO(future): вернуть % 4 и режимы LOAD/SAVE
                    screen2_mode = (screen2_mode + 1) % 2
                    # screen2_mode = (screen2_mode + 1) % 4
                    wavedisp.set_setup_mode(screen2_mode)
                    wavedisp.set_latch_states(latch_states)
                    if screen2_mode == 1 and tune_pad_idx is not None:
                        try:
                            wavedisp.set_tune(_note_name(pad_note_int[tune_pad_idx]), pad_fine_cents[tune_pad_idx])
                        except Exception:
                            pass
                    elif screen2_mode == 1:
                        try:
                            wavedisp.set_tune(None, 0)
                        except Exception:
                            pass
                    key_action = "NONE"
                    continue

        # Screen2: TUNE pot handling (left=coarse -12..+12 steps, right=fine -100..+100)
        if in_screen2 and screen2_mode == 1 and tune_pad_idx is not None:
            k = tune_pad_idx
            base = int(touch_midi_notes[k])

            # pickup relative to our virtual positions tuneA/tuneB
            if abs(tuneA - knobA_new) <= 1000:
                tuneA_pickup = True
            if abs(tuneB - knobB_new) <= 1000:
                tuneB_pickup = True

            changed = False

            if tuneA_pickup:
                tuneA = knobA_new
                pos = int(map_range(tuneA, 0, 65535, 0, 24) + 0.5)
                pos = _clamp(pos, 0, 24)
                coarse_offset = int(pos) - 12
                new_note = base + coarse_offset
                if pad_note_int[k] != new_note:
                    pad_note_int[k] = new_note
                    changed = True

            if tuneB_pickup:
                tuneB = knobB_new
                fine = int(map_range(tuneB, 0, 65535, -100, 100) + 0.5)
                fine = _clamp(fine, -100, 100)
                if pad_fine_cents[k] != fine:
                    pad_fine_cents[k] = fine
                    changed = True

            if changed:
                try:
                    wavedisp.set_tune(_note_name(pad_note_int[k]), pad_fine_cents[k])
                except Exception:
                    pass

                note_val = _note_val_for_pad(k)

                # Если latch ON — обновляем latch-голос на новую ноту
                if latch_states[k]:
                    inst.note_off(latch_play_note[k])
                    latch_play_note[k] = note_val
                    inst.note_on(note_val)

                # retrigger preview-голос только если pad удерживается И latch OFF
                elif tune_pad_pressed[k]:
                    inst.note_off(tune_play_note[k])
                    tune_play_note[k] = note_val
                    inst.note_on(note_val)

                # While in Screen2 we keep playing notes but do not update Screen1 knob params
                await asyncio.sleep(0.02)
                continue
        # Screen2: мы в Screen2 -> НЕ трогаем обработку Screen1 (knob_mode 0..3)
        if in_screen2:
            await asyncio.sleep(0.02)
            continue             
        
        if key := qts.check_key():
            if key.pressed:
                key_held = True
                key_down_time = time.monotonic()
                key_action = "TAP"
                slot_selected = False
                arm_mode = None
                arm_feedback_sent = False

            if key.released:
                key_held = False

                # Long-hold actions consume the release: no knob_mode jump
                if key_action != "TAP":
                    if key_action in ("LOAD_ARMED","SAVE_ARMED") and not slot_selected:
                        try: wavedisp.display_status("Cancel", timeout_ms=800)
                        except Exception: pass
                    # reset
                    key_action = "NONE"
                    key_down_time = None
                    arm_mode = None
                    arm_feedback_sent = False
                    slot_selected = False
                    continue

                # TAP action: change what knobs do (original behavior)
                if not key_with_touch:
                    knobA_pickup, knobB_pickup = False, False
                    knob_saves[knob_mode] = (knobA, knobB)
                    #param_saves[knob_mode] = (paramA, paramB)
                    knob_mode = (knob_mode + 1) % 4
                    wavedisp.selected_info = knob_mode
                    (knobA, knobB) = knob_saves[knob_mode]
                    wavedisp.display_update()

        # timed hold windows for quick save/load and Screen2 reservation
        if key_held and key_down_time is not None and (key_action in ("TAP","LOAD_ARMED","SAVE_ARMED")) and (not slot_selected):
            dt = time.monotonic() - key_down_time
            # 2-5s: quick LOAD, 5-8s: quick SAVE, >=8s: enter Screen2 (Setup)
            if dt >= 8.0:
                # Enter Screen #2 (Setup). Screen2 mode 0 = LATCH
                in_screen2 = True
                screen2_mode = 0
                screen2_ignore_release = True
                screen2_key_down_time = None
                key_action = "ENTER_SETUP"  # consumes release, prevents knob_mode jump
                arm_mode = None
                arm_feedback_sent = True

                wavedisp.set_screen(2)
                wavedisp.set_setup_mode(screen2_mode)
                wavedisp.set_latch_states(latch_states)
                try:
                    wavedisp.set_tune(None, 0)
                except Exception:
                    pass
                wavedisp.display_status("", timeout_ms=1)  # clear bottom line

                # stop further hold-threshold processing until next press
                key_held = False
                key_down_time = None

            elif dt >= 5.0:
                # escalate to SAVE (even if we were already LOAD_ARMED)
                if key_action != "SAVE_ARMED":
                    key_action = "SAVE_ARMED"
                    arm_mode = "save"
                    arm_feedback_sent = False

            elif dt >= 2.0:
                if key_action == "TAP":
                    key_action = "LOAD_ARMED"
                    arm_mode = "load"
                    arm_feedback_sent = False

            # send one-shot feedback when arming
            if arm_mode and not arm_feedback_sent:
                arm_feedback_sent = True
                try:
                    msg = "ARM %s 1-4" % ("LOAD" if arm_mode == "load" else "SAVE")
                    wavedisp.display_status(msg, timeout_ms=900)
                    print(msg)
                except Exception:
                    pass
        # depending on knob mode
        if knob_mode == 0:  # wave selection & wave_mix

            wave_select_pos, wave_mix = param_saves[knob_mode]

            if knobA_pickup:
                wave_select_pos = map_range( knobA, 0,65535, 0, len(wavedisp.wave_selects)-1)
            if knobB_pickup:
                wave_mix = map_range( knobB, 0,65535, 0, 1)

            param_saves[knob_mode] = wave_select_pos, wave_mix

            wave_select = wavedisp.wave_selects[ int(wave_select_pos) ]

            if inst.patch.wave_select() != wave_select:
                reload_patch(wave_select)

            inst.patch.wave_mix = wave_mix

        elif knob_mode == 1:  # osc detune & wave_mix lfo

            detune, wave_lfo = param_saves[knob_mode]

            if knobA_pickup:
                detune  = map_range(knobA, 300,65300, 1, 1.1)  # RP2040 has bad ADC
            if knobB_pickup:
                wave_lfo = map_range(knobB, 0,65535, 0, 1)

            param_saves[knob_mode] = detune, wave_lfo

            inst.patch.wave_mix_lfo_amount = wave_lfo
            inst.patch.detune = detune


        elif knob_mode == 2: # filter type and filter freq
            filt_type, filt_f = param_saves[knob_mode]

            if knobA_pickup:
                filt_type  = int(map_range(knobA, 0,65535, 0,3))
            if knobB_pickup:
                filt_f = map_range(knobB, 300,65300, 100, 8000)

            param_saves[knob_mode] = filt_type, filt_f

            inst.patch.filt_type = filt_type
            inst.patch.filt_f = filt_f

        elif knob_mode == 3:
            filt_q, filt_env = param_saves[knob_mode]

            if knobA_pickup:
                filt_q  = map_range(knobA, 0,65535, 0.5,2.5)
            if knobB_pickup:
                filt_env = map_range(knobB, 300,65300, 1, 0.01)

            param_saves[knob_mode] = filt_q, filt_env

            inst.patch.filt_q = filt_q
            inst.patch.filt_env_params.attack_time = filt_env

        else:
            pass

        await asyncio.sleep(0.02)


print("--- qtpy_synth wavesynth ready ---")

async def main():
    task1 = asyncio.create_task(display_updater())
    task2 = asyncio.create_task(input_handler())
    task3 = asyncio.create_task(midi_handler())
    task4 = asyncio.create_task(instrument_updater())
    await asyncio.gather(task1, task2, task3, task4)

asyncio.run(main())
