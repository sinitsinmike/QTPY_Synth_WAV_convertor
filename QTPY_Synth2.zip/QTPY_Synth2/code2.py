# wavesynth_code.py -- wavesynth for qtpy_synth
# 28 Jul 2023 - @todbot / Tod Kurt
# part of https://github.com/todbot/qtpy_synth
#
#  UI:
#  - Display shows four lines of two parameters each
#  - The current editable parameter pair is underlined, adjustable by the knobs
#  - The knobs have "catchup" logic  (
#       (knob must pass through the displayed value before value can be changed)
#
#  - Key tap (press & release) == change what editable line (what knobs are editing)
#  - Key hold + touch press = load patch 1,2,3,4  (turned off currently)
#  - Touch press/release == play note / release note
#

import asyncio
import time
import usb_midi

from qtpy_synth.hardware import Hardware
from qtpy_synth.synthio_instrument import WavePolyTwoOsc, Patch, FiltType
import qtpy_synth.winterbloom_smolmidi as smolmidi

from wavesynth_display import WavesynthDisplay

import microcontroller
microcontroller.cpu.frequency = 250_000_000

time.sleep(2)  # let USB settle down

touch_midi_notes = [40, 48, 52, 55] # can be float

patch1 = Patch('oneuno')
patch2 = Patch('twotoo')
patch3 = Patch('three')
patch4 = Patch('fourfor')
patches = (patch1, patch2, patch3, patch4)

patch1.filt_env_params.attack_time = 0.1
patch1.amp_env_params.attack_time = 0.01

patch2.filt_type = FiltType.HP
patch2.wave = 'square'
patch2.detune=1.01
patch2.filt_env_params.attack_time = 0.0 # turn off filter  FIXME
patch2.amp_env_params.release_time = 1.0

patch3.waveformB = 'square'  # show off wavemixing
patch3.filt_type = FiltType.BP

patch4.wave_type = 'wtb'
patch4.wave = 'PLAITS02'  # 'MICROW02' 'BRAIDS04'
patch4.wave_mix_lfo_amount = 0.23
#patch4.detune = 0  # disable 2nd oscillator
patch4.amp_env_params.release_time = 0.5

print("--- qtpy_synth wavesynth starting up ---")

qts = Hardware()
inst = WavePolyTwoOsc(qts.synth, patch4)
wavedisp = WavesynthDisplay(qts.display, inst.patch)

# let's get the midi going
midi_usb_in = smolmidi.MidiIn(usb_midi.ports[0])
midi_uart_in = smolmidi.MidiIn(qts.midi_uart)

def map_range(s, a1, a2, b1, b2):  return  b1 + ((s - a1) * (b2 - b1) / (a2 - a1))


def _slot_path(slot_num: int) -> str:
    return "/patches/slot_%03d.json" % slot_num

def _ensure_patches_dir() -> None:
    try:
        os.mkdir("/patches")
    except OSError:
        pass

def _ensure_writable_fs() -> bool:
    try:
        storage.remount("/", readonly=False)
        return True
    except Exception:
        return False

def _patch_to_dict(patch: Patch) -> dict:
    # Minimal persistent patch state (no knob pickup memory)
    return {
        "wave_type": patch.wave_type,
        "wave": patch.wave,
        "waveformA": patch.waveformA,
        "waveformB": patch.waveformB,
        "wave_mix": patch.wave_mix,
        "detune": patch.detune,
        "wave_mix_lfo_amount": patch.wave_mix_lfo_amount,
        "filt_type": int(patch.filt_type),
        "filt_f": patch.filt_f,
        "filt_q": patch.filt_q,
        "filt_env_attack": patch.filt_env_params.attack_time,
        "amp_env_attack": patch.amp_env_params.attack_time,
        "amp_env_release": patch.amp_env_params.release_time,
        # future: pad tuning / latch per patch
    }

def _apply_patch_dict(patch: Patch, d: dict) -> None:
    # Apply persisted patch state
    for k in ("wave_type","wave","waveformA","waveformB"):
        if k in d: setattr(patch, k, d[k])
    patch.wave_mix = float(d.get("wave_mix", patch.wave_mix))
    patch.detune = float(d.get("detune", patch.detune))
    patch.wave_mix_lfo_amount = float(d.get("wave_mix_lfo_amount", patch.wave_mix_lfo_amount))
    if "filt_type" in d: patch.filt_type = int(d["filt_type"])
    if "filt_f" in d: patch.filt_f = float(d["filt_f"])
    if "filt_q" in d: patch.filt_q = float(d["filt_q"])
    if "filt_env_attack" in d: patch.filt_env_params.attack_time = float(d["filt_env_attack"])
    if "amp_env_attack" in d: patch.amp_env_params.attack_time = float(d["amp_env_attack"])
    if "amp_env_release" in d: patch.amp_env_params.release_time = float(d["amp_env_release"])

def save_patch_slot(slot_num: int) -> bool:
    _ensure_patches_dir()
    if not _ensure_writable_fs():
        try: wavedisp.display_status("FS RO")
        except Exception: pass
        print("ERROR: filesystem read-only")
        return False
    path = _slot_path(slot_num)
    d = _patch_to_dict(inst.patch)
    try:
        with open(path, "w") as f:
            json.dump(d, f)
        return True
    except OSError as e:
        print("ERROR saving patch:", e)
        try: wavedisp.display_status("SAVE ERR")
        except Exception: pass
        return False

def load_patch_slot(slot_num: int) -> bool:
    path = _slot_path(slot_num)
    try:
        with open(path, "r") as f:
            d = json.load(f)
    except OSError as e:
        print("ERROR loading patch:", e)
        try: wavedisp.display_status("LOAD ERR")
        except Exception: pass
        return False
    _apply_patch_dict(inst.patch, d)
    wavedisp.patch = inst.patch
    wavedisp.display_update()
    return True




async def instrument_updater():
    while True:
        inst.update()
        await asyncio.sleep(0.01)  # as fast as possible

async def display_updater():
    while True:
        wavedisp.display_update()
        await asyncio.sleep(0.1)


async def midi_handler():
    while True:
        while msg := midi_usb_in.receive() or midi_uart_in.receive():
            if msg.type == smolmidi.NOTE_ON:
                inst.note_on(msg.data[0])
                qts.led.fill(0xff00ff)
            elif msg.type == smolmidi.NOTE_OFF:
                inst.note_off(msg.data[0])
                qts.led.fill(0x000000)
            elif msg.type == smolmidi.CC:
                ccnum = msg.data[0]
                ccval = msg.data[1]
                qts.led.fill(ccval)
                if ccnum == 71:  # "sound controller 1"
                    new_wave_mix = ccval/127
                    print("wave_mix:", new_wave_mix)
                    inst.patch.wave_mix = new_wave_mix
                elif ccnum == 1: # mod wheel
                    inst.patch.wave_mix_lfo_amount = ccval/127 * 50
                    #inst.patch.wave_mix_lfo_rate = msg.value/127 * 5
                elif ccnum == 74: # filter cutoff
                    inst.patch.filt_f = ccval/127 * 8000

        await asyncio.sleep(0.001)


async def input_handler():

    # fixme: put these in qtpy_synth.py? no I think they are part of this "app"
    knob_mode = 0  # 0=frequency, 1=wavemix, 2=, 3=
    key_held = False
    key_with_touch = False
    knob_saves = [ (0,0) for _ in range(4) ]  # list of knob state pairs
    param_saves = [ (0,0) for _ in range(4) ]  # list of param state pairs for knobs
    knobA_pickup, knobB_pickup = False, False
    knobA, knobB = 0,0

    def reload_patch(wave_select):
        print("reload patch!", wave_select)
        # the below seems like the wrong way to do this, needlessly complex
        inst.patch.set_by_wave_select( wave_select )
        inst.reload_patch()
        param_saves[0] = wavedisp.wave_select_pos(), inst.patch.wave_mix
        param_saves[1] = inst.patch.detune, inst.patch.wave_mix_lfo_amount
        param_saves[2] = inst.patch.filt_type, inst.patch.filt_f
        param_saves[3] = inst.patch.filt_q, inst.patch.filt_env_params.attack_time

    while True:
        # KNOB input
        (knobA_new, knobB_new) = qts.read_pots()

        # simple knob pickup logic: if the real knob is close enough to
        if abs(knobA - knobA_new) <= 1000:  # knobs range 0-65535
            knobA_pickup = True
        if abs(knobB - knobB_new) <= 1000:
            knobB_pickup = True

        if knobA_pickup:
            knobA = knobA_new
        if knobB_pickup:
            knobB = knobB_new

        # TOUCH input
        if touches := qts.check_touch():
            for touch in touches:

                if touch.pressed:
                    # Quick Save/Load: active only while KEY is held and armed
                    if key_held and (key_action in ('LOAD_ARMED','SAVE_ARMED')):
                        slot = touch.key_number + 1  # pads are 0..3
                        if key_action == 'LOAD_ARMED':
                            ok = load_patch_slot(slot)
                            wavedisp.display_status(f"Loaded {slot}" if ok else "Load ERR")
                            print("Loaded slot", slot, ok)
                            key_action = 'LOAD_DONE'
                        else:
                            ok = save_patch_slot(slot)
                            wavedisp.display_status(f"Saved {slot}" if ok else "Save ERR")
                            print("Saved slot", slot, ok)
                            key_action = 'SAVE_DONE'
                        slot_selected = True
                        key_with_touch = True
                    else:  # trigger a note

                        qts.led.fill(0xff00ff)
                        midi_note = touch_midi_notes[touch.key_number]
                        inst.note_on(midi_note)

                if touch.released:
                    if key_with_touch:
                        key_with_touch = False
                    else:
                        qts.led.fill(0)
                        midi_note = touch_midi_notes[touch.key_number]
                        inst.note_off(midi_note)

        # KEY input (tap vs hold windows)
        if key := qts.check_key():
            if key.pressed:
                key_held = True
                key_with_touch = False
                slot_selected = False
                load_arm_shown = False
                save_arm_shown = False
                key_action = 'TAP_CANDIDATE'
                key_down_ms = supervisor.ticks_ms()

            if key_held:
                # Update hold windows (only if no slot already selected)
                if not slot_selected and not key_with_touch:
                    held_ms = supervisor.ticks_ms() - key_down_ms
                    if held_ms >= 2000 and held_ms < 5000:
                        if key_action != 'LOAD_ARMED':
                            key_action = 'LOAD_ARMED'
                        if not load_arm_shown:
                            wavedisp.display_status("ARM LOAD 1-4", timeout_ms=1500)
                            load_arm_shown = True
                    elif held_ms >= 5000 and held_ms < 8000:
                        if key_action != 'SAVE_ARMED':
                            key_action = 'SAVE_ARMED'
                        if not save_arm_shown:
                            wavedisp.display_status("ARM SAVE 1-4", timeout_ms=1500)
                            save_arm_shown = True
                    elif held_ms >= 8000:
                        # Reserved for Screen2 in Step 2; do nothing here
                        pass

            if key.released:
                key_held = False

                # If we used the button for a hold action, do not advance knob_mode
                if key_action in ('LOAD_ARMED','SAVE_ARMED') and not slot_selected and not key_with_touch:
                    key_action = 'CANCELLED'
                    wavedisp.display_status("Cancel", timeout_ms=1200)

                if key_action == 'TAP_CANDIDATE' and not key_with_touch:
                    # key tap == change what knobs do
                    knobA_pickup, knobB_pickup = False, False
                    knob_saves[knob_mode] = knobA, knobB  # save knob positions
                    knob_mode = (knob_mode + 1) % 4
                    knobA, knobB = knob_saves[knob_mode]
                    print("knob mode:",knob_mode, knobA, knobB)
                    wavedisp.selected_info = knob_mode

                # reset action after release
                key_action = 'NONE'
                slot_selected = False
                key_with_touch = False

        # Handle parameter changes depending on knob mode
        if knob_mode == 0:  # wave selection & wave_mix

            wave_select_pos, wave_mix = param_saves[knob_mode]

            if knobA_pickup:
                wave_select_pos = map_range( knobA, 0,65535, 0, len(wavedisp.wave_selects)-1)
            if knobB_pickup:
                wave_mix = map_range( knobB, 0,65535, 0, 1)

            param_saves[knob_mode] = wave_select_pos, wave_mix

            wave_select = wavedisp.wave_selects[ int(wave_select_pos) ]

            if inst.patch.wave_select() != wave_select:
                reload_patch(wave_select)

            inst.patch.wave_mix = wave_mix

        elif knob_mode == 1:  # osc detune & wave_mix lfo

            detune, wave_lfo = param_saves[knob_mode]

            if knobA_pickup:
                detune  = map_range(knobA, 300,65300, 1, 1.1)  # RP2040 has bad ADC
            if knobB_pickup:
                wave_lfo = map_range(knobB, 0,65535, 0, 1)

            param_saves[knob_mode] = detune, wave_lfo

            inst.patch.wave_mix_lfo_amount = wave_lfo
            inst.patch.detune = detune


        elif knob_mode == 2: # filter type and filter freq
            filt_type, filt_f = param_saves[knob_mode]

            if knobA_pickup:
                filt_type  = int(map_range(knobA, 0,65535, 0,3))
            if knobB_pickup:
                filt_f = map_range(knobB, 300,65300, 100, 8000)

            param_saves[knob_mode] = filt_type, filt_f

            inst.patch.filt_type = filt_type
            inst.patch.filt_f = filt_f

        elif knob_mode == 3:
            filt_q, filt_env = param_saves[knob_mode]

            if knobA_pickup:
                filt_q  = map_range(knobA, 0,65535, 0.5,2.5)
            if knobB_pickup:
                filt_env = map_range(knobB, 300,65300, 1, 0.01)

            param_saves[knob_mode] = filt_q, filt_env

            inst.patch.filt_q = filt_q
            inst.patch.filt_env_params.attack_time = filt_env

        else:
            pass

        await asyncio.sleep(0.02)


print("--- qtpy_synth wavesynth ready ---")

async def main():
    task1 = asyncio.create_task(display_updater())
    task2 = asyncio.create_task(input_handler())
    task3 = asyncio.create_task(midi_handler())
    task4 = asyncio.create_task(instrument_updater())
    await asyncio.gather(task1, task2, task3, task4)

asyncio.run(main())
