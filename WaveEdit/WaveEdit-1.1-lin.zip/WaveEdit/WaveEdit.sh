#!/bin/sh
LD_LIBRARY_PATH=. ./WaveEdit